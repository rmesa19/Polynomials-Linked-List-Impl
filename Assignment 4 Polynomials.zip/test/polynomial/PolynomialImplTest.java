package polynomial;

import org.junit.Test;

import static org.junit.Assert.*;

public class PolynomialImplTest {

  PolynomialImpl myList = new PolynomialImpl();


  @Test
  public void addTerm() {

    System.out.println(myList.toString());
    myList.addTerm(3, 1);
    System.out.println(myList.toString());
    myList.addTerm(5, 1);
    System.out.println(myList.toString());
    myList.addTerm(5, 2);
    System.out.println(myList.toString());
    myList.addTerm(5, 5);
    System.out.println(myList.toString());
    myList.addTerm(5, 4);
    myList.addTerm(0, 4);
    System.out.println(myList.toString());



  }

  @Test
  public void removeTerm() {

    myList.addTerm(5, 0);
    System.out.println(myList.toString());
    myList.addTerm(5, 1);
    System.out.println(myList.toString());
    myList.addTerm(5, 2);
    System.out.println(myList.toString());
    myList.addTerm(5, 5);
    System.out.println(myList.toString());
    myList.removeTerm(6);
    System.out.println(myList.toString());
    myList.removeTerm(5);
    System.out.println(myList.toString());
    myList.removeTerm(0);
    System.out.println(myList.toString());
  }

  @Test
  public void getDegree() {

    myList.addTerm(3, 0);
    assertEquals(myList.getDegree(), 0);
    myList.addTerm(3, 2);
    assertEquals(myList.getDegree(), 2);
    myList.addTerm(3, 3);
    assertEquals(myList.getDegree(), 3);



  }

  @Test
  public void getCoefficient() {

    PolynomialImpl otherList = new PolynomialImpl("-5x^1 -3x^2 2x^1 -7");
    System.out.println(otherList.toString());
    PolynomialImpl nextList = new PolynomialImpl("-5x^1 3x^2 2x^1");
    System.out.println(nextList.toString());
    System.out.println(otherList.getCoefficient(2));
    System.out.println(otherList.getCoefficient(0));
    System.out.println(otherList.getCoefficient(6));

  }

  @Test
  public void evaluate() {

    myList.addTerm(5, 1);
    myList.addTerm(5, 2);
    myList.addTerm(-5, 5);
    myList.addTerm(-5, 7);
    System.out.println(myList.toString());
    System.out.println(myList.evaluate(6));
    System.out.println(myList.evaluate(-5));
    System.out.println(myList.evaluate(.7));
    System.out.println(myList.evaluate(-.7));
  }

  @Test
  public void add() {

    myList.addTerm(5, 1);
    myList.addTerm(5, 2);
    PolynomialImpl otherList = new PolynomialImpl("-5x^1 -3x^2 2x^1 4x^8");
    System.out.println(myList.add(otherList).toString());
  }

  @Test
  public void testToString() {

    myList.addTerm(5, 1);
    System.out.println(myList.toString());
    myList.addTerm(5, 2);
    System.out.println(myList.toString());
    myList.addTerm(-5, 5);
    System.out.println(myList.toString());
    myList.addTerm(-5, 7);
    System.out.println(myList.toString());
    myList.addTerm(0, 0);
    System.out.println(myList.toString());

  }
}